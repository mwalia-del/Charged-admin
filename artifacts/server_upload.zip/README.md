# Charged Admin API Artifacts

Generated: 2025-09-15T00:36:26.753Z

## Files

- **openapi.json**: Complete OpenAPI 3.0 specification
- **endpoints.json**: Structured endpoint inventory with metadata
- **endpoints.csv**: Endpoint data in CSV format for import
- **postman_collection.json**: Postman collection for API testing

## Usage

1. Import `openapi.json` into API documentation tools
2. Use `endpoints.csv` for endpoint management systems
3. Import `postman_collection.json` into Postman for testing
4. Reference `endpoints.json` for programmatic access to endpoint data

## Endpoint Counts

- Total Endpoints: 65
- Methods: GET: 35, PUT: 9, POST: 16, DELETE: 5
- Tags: Rider: 14, Ride: 4, Driver: 21, Admin: 25, Payment: 1
- Deprecated: 0

