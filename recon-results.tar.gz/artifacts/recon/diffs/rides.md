# Rides discrepancies

| Day | Status | DB rides | DB total_fare | API note | Δ |
|---|---:|---:|---:|---|---:|